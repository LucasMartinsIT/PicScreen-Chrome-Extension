let allImages = [];
let currentPage = 1;
const itemsPerPage = 26;

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("btn-extract").innerText =
    chrome.i18n.getMessage("btnAnalyze") || "Analisar Página";
  document.getElementById("btn-download").innerText =
    chrome.i18n.getMessage("btnDownload") || "Baixar Tudo em .ZIP";

  const footerText =
    chrome.i18n.getMessage("footerText") || "☕ Poupou seu tempo? ";
  const footerLink =
    chrome.i18n.getMessage("footerLink") || "Pague-me um café!";
  document.getElementById("footer-content").innerHTML =
    `${footerText} <a href="https://ko-fi.com/lucasmartins1991" target="_blank">${footerLink}</a>`;

  // 👉 NOVAS LINHAS AQUI: Tradução dos novos títulos e labels
  document.getElementById("label-colors").innerText =
    chrome.i18n.getMessage("labelColors") || "Cores";
  document.getElementById("title-site-palette").innerText =
    chrome.i18n.getMessage("titleSitePalette") || "Paleta do Site (Design)";
  document.getElementById("title-image-palette").innerText =
    chrome.i18n.getMessage("titleImagePalette") || "Paleta das Imagens (Arte)";
  // Tradução do Conta-Gotas
  document.getElementById("title-eyedropper").innerText =
    chrome.i18n.getMessage("titleEyedropper") || "Conta-gotas (Cor Específica)";
  document.getElementById("btn-eyedropper").innerText =
    chrome.i18n.getMessage("btnEyedropper") || "Pegar cor";

  // 👉 NOVO: Lógica de abrir/fechar a Paleta do Site
  const toggleSite = document.getElementById("toggle-site-palette");
  const siteContainer = document.getElementById("site-palette-container");
  toggleSite.addEventListener("click", () => {
    siteContainer.classList.toggle("collapsed"); // Adiciona ou remove a classe
    const arrow = toggleSite.querySelector(".arrow");
    arrow.innerText = siteContainer.classList.contains("collapsed") ? "►" : "▼";
  });

  // 👉 NOVO: Lógica de abrir/fechar a Paleta das Imagens
  const toggleImage = document.getElementById("toggle-image-palette");
  const imageContainer = document.getElementById("image-palette-container");
  toggleImage.addEventListener("click", () => {
    imageContainer.classList.toggle("collapsed");
    const arrow = toggleImage.querySelector(".arrow");
    arrow.innerText = imageContainer.classList.contains("collapsed")
      ? "►"
      : "▼";
  });
});

document.getElementById("btn-extract").addEventListener("click", async () => {
  const btn = document.getElementById("btn-extract");
  const limitInput = parseInt(document.getElementById("palette-limit").value);
  const maxColors = limitInput > 0 ? limitInput : 10;

  btn.innerText = "Analisando... aguarde";
  btn.disabled = true;

  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.tabs.sendMessage(
    tab.id,
    { action: "extract_data", limit: maxColors },
    (response) => {
      btn.innerText = chrome.i18n.getMessage("btnAnalyze") || "Analisar Página";
      btn.disabled = false;

      if (!response) return;

      renderizarCores("site-palette-container", response.sitePalette);
      renderizarCores("image-palette-container", response.imagePalette);

      allImages = response.images;
      currentPage = 1;
      renderGallery();

      document.getElementById("btn-download").style.display = "block";
    },
  );
});

function renderizarCores(containerId, arrayDeCores) {
  const container = document.getElementById(containerId);
  container.innerHTML = "";

  arrayDeCores.forEach((hex) => {
    let colorBox = document.createElement("div");
    colorBox.className = "color-box";
    colorBox.style.backgroundColor = hex;
    colorBox.innerHTML = `<span>${hex}</span>`;

    if (hex === "#ffffff") colorBox.querySelector("span").style.color = "#000";

    colorBox.addEventListener("click", () => {
      navigator.clipboard.writeText(hex);
      colorBox.querySelector("span").innerText = "Copiado!";
      setTimeout(() => (colorBox.querySelector("span").innerText = hex), 1500);
    });
    container.appendChild(colorBox);
  });
}

async function renderGallery() {
  const gallery = document.getElementById("gallery");

  // 1. Mensagem de Loading para o usuário não achar que travou
  gallery.innerHTML =
    "<div style='grid-column: 1 / -1; text-align: center; color: #888; padding: 20px 0;'>Carregando referências... ⌛</div>";

  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const imagesToShow = allImages.slice(startIndex, endIndex);

  // 2. 👉 O SEU CONCEITO AQUI: Espera todas as imagens da página carregarem na memória primeiro
  await Promise.all(
    imagesToShow.map((src) => {
      return new Promise((resolve) => {
        const img = new Image();
        img.onload = resolve;
        img.onerror = resolve; // Resolve mesmo se der erro, para não travar a fila
        img.src = src;
      });
    }),
  );

  // 3. Limpa o Loading
  gallery.innerHTML = "";

  // 4. Injeta tudo na tela de uma vez, agora que o Chrome já sabe o tamanho exato de cada uma
  imagesToShow.forEach((src) => {
    let wrapper = document.createElement("div");
    wrapper.className = "img-container";

    let imgElement = document.createElement("img");
    imgElement.src = src;

    let btnDown = document.createElement("button");
    btnDown.className = "btn-single-down";
    btnDown.innerHTML = "📥";
    btnDown.title = "Baixar esta imagem";

    btnDown.addEventListener("click", async () => {
      btnDown.innerHTML = "⌛";
      try {
        const response = await fetch(src);
        const blob = await response.blob();

        const urlParts = src.split("/");
        let filename = urlParts[urlParts.length - 1].split("?")[0];
        if (!filename.includes(".")) filename = `ref_unica_${Date.now()}.jpg`;

        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = filename;
        link.click();

        btnDown.innerHTML = "✔️";
        setTimeout(() => (btnDown.innerHTML = "📥"), 1500);
      } catch (e) {
        btnDown.innerHTML = "❌";
        console.warn("Falha ao baixar imagem única:", src);
      }
    });

    wrapper.appendChild(imgElement);
    wrapper.appendChild(btnDown);
    gallery.appendChild(wrapper);
  });

  updatePaginationControls();
}

function updatePaginationControls() {
  const controls = document.getElementById("pagination-controls");
  const btnPrev = document.getElementById("btn-prev");
  const btnNext = document.getElementById("btn-next");
  const pageInfo = document.getElementById("page-info");

  if (allImages.length > itemsPerPage) {
    controls.style.display = "flex";
    const totalPages = Math.ceil(allImages.length / itemsPerPage);
    pageInfo.innerText = `${currentPage}/${totalPages}`;
    btnPrev.disabled = currentPage === 1;
    btnNext.disabled = currentPage === totalPages;
  } else {
    controls.style.display = "none";
  }
}

document.getElementById("btn-prev").addEventListener("click", () => {
  if (currentPage > 1) {
    currentPage--;
    renderGallery();
  }
});
document.getElementById("btn-next").addEventListener("click", () => {
  const totalPages = Math.ceil(allImages.length / itemsPerPage);
  if (currentPage < totalPages) {
    currentPage++;
    renderGallery();
  }
});

// LÓGICA DO DOWNLOAD (JSZip)
document.getElementById("btn-download").addEventListener("click", async () => {
  const btnDownload = document.getElementById("btn-download");
  btnDownload.innerText = "Empacotando... aguarde";
  btnDownload.disabled = true;

  const zip = new JSZip();
  const imgFolder = zip.folder("referencias_visuais");

  for (let i = 0; i < allImages.length; i++) {
    try {
      const response = await fetch(allImages[i]);
      const blob = await response.blob();
      const urlParts = allImages[i].split("/");
      let filename = urlParts[urlParts.length - 1].split("?")[0];
      if (!filename.includes(".")) filename = `ref_${i}.jpg`;
      imgFolder.file(filename, blob);
    } catch (e) {
      console.warn("Falha ao incluir imagem no ZIP:", allImages[i]);
    }
  }

  zip.generateAsync({ type: "blob" }).then(function (content) {
    const link = document.createElement("a");
    link.href = URL.createObjectURL(content);
    link.download = "moodboard_referencias.zip";
    link.click();
    btnDownload.innerText =
      chrome.i18n.getMessage("btnDownload") || "Baixar Tudo em .ZIP";
    btnDownload.disabled = false;
  });
});

// 👉 4. LÓGICA DO CONTA-GOTAS NATIVO
document
  .getElementById("btn-eyedropper")
  .addEventListener("click", async () => {
    // Verifica se o navegador suporta a ferramenta
    if (!window.EyeDropper) {
      alert("Seu navegador não suporta a ferramenta de Conta-gotas nativa.");
      return;
    }

    try {
      const eyeDropper = new EyeDropper();
      // Abre a lupa do sistema
      const result = await eyeDropper.open();
      const hex = result.sRGBHex;

      // Atualiza a caixinha com a cor escolhida
      const resultBox = document.getElementById("eyedropper-result");
      resultBox.style.backgroundColor = hex;
      resultBox.style.border = "none";

      const span = resultBox.querySelector("span");
      span.innerText = hex;

      // Ajusta o texto se a cor for branca
      if (hex.toLowerCase() === "#ffffff") span.style.color = "#000";
      else span.style.color = "#fff";

      // Adiciona o clique para copiar
      resultBox.onclick = () => {
        if (span.innerText !== "Vazio" && span.innerText !== "Empty") {
          navigator.clipboard.writeText(hex);
          span.innerText = "Copiado!";
          setTimeout(() => (span.innerText = hex), 1500);
        }
      };
    } catch (e) {
      // Cai aqui se o usuário apertar "ESC" e cancelar o conta-gotas
      console.log("Seleção de cor cancelada.");
    }
  });
